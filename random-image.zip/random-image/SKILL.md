---
name: random-image
description: This skill should be used when users need to generate or retrieve random images for various purposes such as placeholder images, testing, presentations, or creative projects. The skill provides multiple random image APIs and tools for image manipulation and optimization. Use this when users request random images, placeholder images, sample images, or need to fetch images from random sources.
---

# Random Image Skill

## Overview

This skill enables Claude to generate, retrieve, and optimize random images from multiple reliable APIs. It supports various use cases including placeholder images for development, random photos for presentations, and image optimization tools.

## Available Random Image APIs

### 1. Lorem Picsum (Recommended)

The most reliable random image service with high-quality photos.

**Basic Usage:**
```
https://picsum.photos/200
https://picsum.photos/200/300
```

**Specific Image:**
```
https://picsum.photos/id/237/200/300
https://picsum.photos/id/1011/200/300
```

**Key Features:**
- High-quality photos from Unsplash
- Specific image by ID: `/id/{id}/width/height`
- Random image: `/width/height`
- Grayscale: `/200/300?grayscale`
- Blur: `/200/300?blur=10`
- Random seed: `/seed/{seed}/200/300`

### 2. Unsplash Source

Direct access to Unsplash's random photos by topic.

**Topics Available:**
- Architecture: `https://source.unsplash.com/featured/?architecture`
- Nature: `https://source.unsplash.com/featured/?nature`
- Technology: `https://source.unsplash.com/featured/?technology`
- People: `https://source.unsplash.com/featured/?people`
- Business: `https://source.unsplash.com/featured/?business`
- Animals: `https://source.unsplash.com/featured/?animals`
- Food: `https://source.unsplash.com/featured/?food`
- Sports: `https://source.unsplash.com/featured/?sports`
- Fashion: `https://source.unsplash.com/featured/?fashion`
- Art: `https://source.unsplash.com/featured/?art`

**With Size:**
```
https://source.unsplash.com/800x600/?nature
```

### 3. Pexels Random

High-quality photos from Pexels (requires topic search).

**Usage Pattern:**
```
https://images.pexels.com/photos/{photo_id}/pexels-photo-{photo_id}.jpeg
```

Common Pexels photo IDs:
- Landscape: 1287145, 1261728, 1562
- Nature: 1671325, 1366919, 1676276
- Urban: 373290, 632397, 374870

### 4. Multiple Images Collection

**Lorem Picsum List:**
```
https://picsum.photos/v2/list?page=1&limit=10
```

Returns JSON with multiple image URLs.

## Quick Reference

| Use Case | API URL |
|----------|---------|
| Random 200x200 | `https://picsum.photos/200` |
| Random specific size | `https://picsum.photos/800/600` |
| Grayscale random | `https://picsum.photos/400/300?grayscale` |
| Blur effect | `https://picsum.photos/400/300?blur=5` |
| By topic (nature) | `https://source.unsplash.com/featured/?nature` |
| Specific photo ID | `https://picsum.photos/id/237/400/400` |
| With seed (reproducible) | `https://picsum.photos/seed/same/400/400` |

## Common Use Cases

### 1. Placeholder Images

For development and design mockups:

```markdown
![Random Placeholder](https://picsum.photos/400/300)
```

### 2. Random Photos by Category

```markdown
![Nature](https://source.unsplash.com/featured/?nature)
![Technology](https://source.unsplash.com/featured/?technology)
![Architecture](https://source.unsplash.com/featured/?architecture)
```

### 3. Consistent Random Images (Seed)

Use seed parameter to get the same image across requests:

```markdown
![Same Image](https://picsum.photos/seed/user123/400/300)
```

### 4. Profile Pictures

```markdown
![Avatar](https://picsum.photos/id/237/200/200)
![User Photo](https://picsum.photos/id/64/200/200)
```

### 5. Background Images

```markdown
![Background](https://picsum.photos/1920/1080?grayscale)
```

## Image Optimization Tips

### Resize for Performance

- Use specific dimensions: `https://picsum.photos/400/300` (not original size)
- Smaller sizes = faster loading
- Consider aspect ratios for your layout

### Format Options

- Lorem Picsum supports: JPEG, WebP (with ?fm=webp)
- Example: `https://picsum.photos/400/300?grayscale&fm=webp`

### Caching

- Images from these APIs are cached
- Use seed parameter for consistent images across page loads
- Example: `https://picsum.photos/seed/myapp-logo/200/200`

## Scripts

This skill includes helper scripts in the `scripts/` directory for advanced image operations.

### Image URL Generator

Generate random image URLs with specific parameters:

```bash
python scripts/generate_image_url.py --width 800 --height 600 --grayscale
```

### Batch Image Fetcher

Fetch multiple random images for collections:

```bash
python scripts/fetch_images.py --count 10 --output ./images
```

## Troubleshooting

### API Not Working

- Check internet connectivity
- Try alternative API endpoint
- Clear cache if using cached URLs

### Slow Loading

- Use smaller dimensions
- Choose nearest CDN location
- Consider image compression

### Consistent Results Needed

- Always use seed parameter
- Store specific photo IDs for reuse
- Document which images are used where

## Additional Resources

- Lorem Picsum Documentation: https://picsum.photos/
- Unsplash API: https://unsplash.com/developers
- Image Format Guide: https://developers.google.com/speed/webp

---

**Note:** Image availability depends on third-party services. If an image fails to load, try an alternative API or refresh the URL.
